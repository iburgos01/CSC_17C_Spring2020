/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   TriMatx.h
 * Author: Ivan Burgos
 * Created on February 26, 2020, 10:32 AM
 * Purpose: Structure of Triangular Array
 */

#ifndef TRIMATX_H
#define TRIMATX_H

struct TriMatx{
    int size;           //Represents the number of rows
    int *col;          //Represents the column array, i.e. number of columns for each row
    int *indx;      //Represents the index matrix which you can sort to use for display
    int **data;    //Represents the data contents of the Triangular matrix
};

#endif /* TRIMATX_H */

