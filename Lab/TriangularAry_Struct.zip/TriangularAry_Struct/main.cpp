/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on February 19, 2020, 11:51 AM
 * Purpose: Implementing structure for Triangular Array
 */

//System Level Libraries
#include <iostream>   //I/O Library
#include <cstdlib>
#include <ctime>
using namespace std;  //Library Scope

//User Libraries
#include "TriMatx.h"
//Global Constants
//Science and Math, Conversions, Higher Dimensions
//const to follow

//Function Prototypes
int *filAray(int);
int **filAray(int *,int,int,int);
void destroy(int *);
void destroy(int **,int);
void prntAry(int *,int,int);
void prntAry(int **,int,int);
void mrkSort(int *,int);

//Execution Starts Here
int main(int argc, char** argv){
    //Set Random Number Seed Here
    srand(static_cast<unsigned int>(time(0)));
    //Declare Variables - Known and Unknown, units, range, description
    TriMatx array;
    //Initialize Variables
    array.size=10;
    //Map inputs to outputs -> i.e. process the inputs
    
    //Display the outputs
    
    //Clean up - File closing, memory deallocation, etc....

    //Exit Stage Right!
    return 0;
}

//Function Implementations