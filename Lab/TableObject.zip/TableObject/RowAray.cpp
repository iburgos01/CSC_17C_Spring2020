/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include <cstdlib>

#include "RowAray.h"
using namespace std;

RowAray::RowAray(int n){
    if(n>0){
        size=n;
        rowData=new int[size];
        for(int i=0;i<size;i++){
            rowData[i]=rand()%90+10;
        }
    }
    else{
        size=0;
        rowData=0;
    }
}

RowAray::~RowAray(){
    delete []rowData;
}