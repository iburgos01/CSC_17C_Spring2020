/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include "Table.h"
using namespace std;

Table::Table(int row, int col){
    if(row>0&&col>0){
        szRow=row;
        szCol=col;
        records=new RowAray*[szRow];
        for(int i=0;i<szRow;i++){
            records[i]=new RowAray(szCol);
        }
    }
    else{
        szRow=0;
        szCol=0;
        records=0;        
    }
}

Table::~Table(){
    for(int i=0;i<szRow;i++){
        delete []records[i];
    }
    
    delete []records;
}

Table::getData(int row, int col){
    if(row>0&&col>0){
        for(int i=0;i<row;i++){
            return records[i]->getData(col);
        }
    }
    else return 0;
}